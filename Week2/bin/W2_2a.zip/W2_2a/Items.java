package W2_2a;

public interface Items {
    void use();
}
