package W2_2a;

public class medikit implements Items {
    @Override
    public void use(){
        System.out.println("use medikits and healthpacks!!");
    }
    
}
