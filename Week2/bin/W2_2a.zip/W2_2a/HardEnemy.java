package W2_2a;

public class HardEnemy implements Enemy{
    @Override
    public void attack(){
        System.out.println("Hard attack");
    }
}
