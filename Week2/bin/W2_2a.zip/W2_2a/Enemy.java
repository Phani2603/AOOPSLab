package W2_2a;

public interface Enemy {
    public abstract void attack();
    
} 
