package W2_2a;
public class EasyEnemy implements Enemy{
    @Override
    public void attack(){
        System.out.println("easy enemy");
    }
}
