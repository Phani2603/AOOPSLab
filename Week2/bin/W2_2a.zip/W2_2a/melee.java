package W2_2a;
public class melee implements Items {
    @Override
    public void use(){
        System.out.println("use melee weapon");
    }    
}
  