package W2_2a;

public class Magic implements Items{
    @Override
    public void use(){
        System.out.println("use magic attack!!");
    }
}
