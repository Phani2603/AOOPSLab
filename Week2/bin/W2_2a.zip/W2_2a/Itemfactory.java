package W2_2a;

public abstract class Itemfactory {
    public abstract Items createWeapon();
    public abstract Items createPowerUp();
}
